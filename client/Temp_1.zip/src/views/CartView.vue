<template>
    <div class="CART">
      <h1>CART PAGE</h1>
    </div>
  </template>