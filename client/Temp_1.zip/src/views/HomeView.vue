<template>
    <div class="home">
      <h1> Nag</h1>
    </div>
  </template>
  <script>
    export default {
      name: 'HomeView',
      components: {},
    };
  </script>
  <style lang="scss" scoped>
  </style>
